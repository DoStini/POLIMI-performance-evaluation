fprintf("Calculating Trace1.csv\n");
calculate("Trace1.csv");
fprintf("-------------\n\n");


fprintf("Calculating Trace2.csv\n");
calculate("Trace2.csv");
fprintf("-------------\n\n");

fprintf("Calculating Trace3.csv\n");
calculate("Trace3.csv");
fprintf("-------------\n\n");


