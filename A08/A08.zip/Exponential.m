function [exponential] = Exponential(l)
    exponential = -log(rand()) / l;
end

